# Summary of Thursday June 03
 unexpectedly successful. it seems that the problem originated from incorrect qubit connection topology.
It is the uniform qasvm model for now, but surprisingly, it can classify data.

The QASVM model and related data (i.e. history of SPSA iteration, data used for plotting regression line) are saved in /model/ directory.
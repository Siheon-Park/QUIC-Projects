import numpy as np
import math
import matplotlib.pyplot as plt
from abc import ABC, abstractmethod
from cvxopt import matrix, solvers # pylint: disable=import-error
from classification import * # pylint: disable=unused-wildcard-import
from classification.optimizer import QpDuel

# qiskit
from qiskit.circuit import QuantumCircuit
from qiskit.circuit import QuantumRegister, ClassicalRegister
from qiskit.circuit import Qubit
from qiskit.circuit import Instruction, Gate
from qiskit.circuit.library.standard_gates import XGate, ZGate
from qiskit.extensions.quantum_initializer.initializer import Initialize
from qiskit import transpile, QiskitError
from qiskit import execute

# custum qiskit
from custom_qiskit.quantum_encoder import Encoder

class SVM(Classifier):
    def __init__(self, data, label, kernel='power2', name='support vector machine'):
        """
            SVM

            kernel: return n by n matrix input: matrix X, Y
            @property: kernel(setter) opt_dict, 
            super @property: data, label, is_opt, name
            public: alpha, support_vector_index, support_vector
        """
        super().__init__(data, label, name)
        if kernel=='power2':
            self._kernel = lambda X, Y: np.abs(X @ Y.T)**2
        else:
            self._kernel = kernel
        self.alpha = None
        self.support_vector_index = None
        self.support_vector = None


    @property
    def kernel(self):
        return self._kernel

    @property
    def opt_dict(self):
        return self._opt_dict

    @kernel.setter
    def kernel(self, func):
        if self._kernel != func:
            self._kernel = func
            self._is_opt = False
            self._opt_dict = None

    def optimize(self, opt:Optimizer=QpDuel, **kwargs):
        opt(self, **kwargs)


    def classify(self, test:np.ndarray):
        svi = self.support_vector_index
        # return np.sign((np.random.rand(*self.alpha.shape)*self.label).reshape(1, -1) @ self.kernel(self.data, test)) # pylint: disable=not-callable
        return np.sign((self.alpha[svi]*self.label[svi]).reshape(1, -1) @ self.kernel(self.support_vector, test))

    def check_perfomance(self, test_data:np.ndarray, test_label: np.ndarray, **kwargs):
        _temp = self.classify(test_data)==test_label
        performance = np.sum(_temp)/_temp.size
        self.testerr = 1 - performance
        return performance

    def plot(self, axes=plt, **kwargs):
        cmap = kwargs.get('cmap', plt.cm.coolwarm)# pylint: disable=no-member
        s = kwargs.get('s', 100)
        linewidth = kwargs.get('linewidth', 1.0)
        facecolors = kwargs.get('facecolor', 'none')
        edgecolors = kwargs.get('edgecolors', 'k')
        sv = kwargs.get('sv', True)
        if sv:
            sc = axes.scatter(self.data[:,0], self.data[:,1], c=self.label, cmap=cmap)
            axes.scatter(self.support_vector[:,0], self.support_vector[:,1], s=s, linewidth=linewidth, facecolors=facecolors, edgecolors=edgecolors)
        else:
            sc = axes.scatter(self.data[:,0], self.data[:,1], c=self.alpha*self.label)
        if axes==plt:
            plt.colorbar()
            axes.title(f'{self.name}')
        else:
            plt.colorbar(sc, ax=axes)
            axes.set_title(f'{self.name}')
        axes.grid()

class SWAPclassifier(Classifier):
    def __init__(self, data, label):
        """
            SWAP classifier

            super @property: data, label, is_opt, name
            public: alpha, support_vector_index, support_vector
        """
        super().__init__(data, label, 'SWAP classifier')
        self.alpha = None
        self.quantum_circuit = None
        self.sqrt_weight_encoding_gate = None
        
        n_data = self.data.shape[0]
        d_data = self.data.shape[1]
        index_qubit_num = int(np.ceil(np.log2(n_data)))
        data_qubit_num = int(np.ceil(np.log2(d_data)))
        qr_a = QuantumRegister(1, name='ancila')
        qr_i = QuantumRegister(index_qubit_num, name='index')
        qr_x = QuantumRegister(data_qubit_num, name='data')
        qr_y = QuantumRegister(1, name='label')
        qr_xt = QuantumRegister(data_qubit_num, name='test')
        cr = ClassicalRegister(2, name='c')

        self.qreg = [qr_a, qr_i, qr_x, qr_y, qr_xt]
        self.creg = [cr]
        qc = QuantumCircuit(*self.qreg, *self.creg, name="training & classification")
        [qc.ctrl_encode(self.data[i], i, qr_x, qr_i, name=f"Data {i}") for i in range(n_data)] # data encoding
        [qc.ctrl_x(i, qr_y, qr_i) if label[i]>0 else None for i in range(n_data)] # label encoding
        qc.barrier()
        # SWAP test
        qc.h(qr_a)
        [qc.cswap(qr_a, qr_x[i], qr_xt[i]) for i in range(data_qubit_num)]
        qc.h(qr_a)
        # measure
        qc.measure(qr_a, cr[0]) # pylint: disable=no-member
        qc.measure(qr_y, cr[1]) # pylint: disable=no-member
        self.training_circ = qc

    def optimize(self, opt:Optimizer, **kwargs):
        opt(self, **kwargs)

    def classify(self, test: np.ndarray, backend=None, **kwargs):
        """if backend is None, return classification circuit(s)"""
        if test.ndim > 1:
            qc = [self._construct_circuit_with(t) for t in test] 
        else: 
            qc = self._construct_circuit_with(test)
        self.classifier_circ = qc
        if backend is not None:
            jobs = execute(qc, backend, **kwargs)
            return self._process(jobs.result().get_counts())
        else:
            return qc

    def check_perfomance(self, test_data:np.ndarray, test_label: np.ndarray, backend, **kwargs):
        _temp = self.classify(test_data, backend)==test_label
        performance = np.sum(_temp)/_temp.size
        self.testerr = 1 - performance
        return performance

    def _construct_circuit_with(self, test:np.ndarray):
        qc = QuantumCircuit(*(self.qreg+self.creg), name='classifier circuit')
        qc.encode(test, self.qreg[-1], 'test data')
        qc = qc.combine(self.training_circ)      
        return qc  
    
    def _process(self, results):
        labels =[]
        for result in results:
            c00 = result.get('00', 0)
            c01 = result.get('01', 0)
            c10 = result.get('10', 0)
            c11 = result.get('11', 0)
            labels.append(-np.sign((c00+c11-c01-c10)/(c00+c01+c10+c11))) # convention 
        return np.array(labels)

class QMinicClassifier(SWAPclassifier):
    def __init__(self, svm:SVM):
        """
            SWAP classifier that mimics classical svm

            super @property: data, label, is_opt, name
            public: alpha, support_vector_index, support_vector
        """
        data = svm.support_vector
        label = svm.label[svm.support_vector_index]
        super().__init__(data, label)
        self.original_svm = svm
    
    def optimize(self):
        svi = self.original_svm.support_vector_index
        alpha = self.original_svm.alpha
        weight = np.sqrt(alpha[svi])
        qc = QuantumCircuit(*(self.qreg+self.creg), name='Mimic SVM circuit')
        qc.encode(weight, self.qreg[1], 'Optimized Weight')
        qc = qc.combine(self.training_circ)
        self.training_circ = qc
